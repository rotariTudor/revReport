package com.thrust.revreport

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bluetoothManager = getSystemService(BluetoothManager::class.java)
        val btManager = revReportBluetoothManagement(bluetoothManager.adapter)

        setContent {
            val context = LocalContext.current
            val coroutineScope = rememberCoroutineScope()

            val connectToObd = {
                coroutineScope.launch {
                    try {
                        val pairedDevices = btManager.bluetoothAdapter?.bondedDevices
                        val laptop = pairedDevices?.find { it.name?.equals("DESKTOP-I6T331R", ignoreCase = true) == true }

                        if (laptop != null) {
                            Toast.makeText(context, "Laptop găsit! Mă conectez...", Toast.LENGTH_SHORT).show()

                            // CRITIC: Mutăm conectarea fizică pe un fir de fundal (I/O) pentru a nu bloca și crăpa ecranul
                            val isConnected = withContext(Dispatchers.IO) {
                                btManager.connect(laptop)
                            }

                            if (isConnected) {
                                Toast.makeText(context, "Conectat! Inițializez...", Toast.LENGTH_SHORT).show()
                                withContext(Dispatchers.IO) {
                                    btManager.initializeAdapter()
                                }
                            } else {
                                Toast.makeText(context, "Eșec la deschiderea portului pe PC.", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Eroare: Laptopul NU este asociat!", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: SecurityException) {
                        Toast.makeText(context, "Sistemul a blocat Bluetooth-ul!", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(context, "Eroare internă: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { permissions ->
                val allGranted = permissions.entries.all { it.value }
                if (allGranted) {
                    connectToObd()
                } else {
                    Toast.makeText(context, "Aplicația are nevoie de permisiuni.", Toast.LENGTH_LONG).show()
                }
            }

            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Button(onClick = {
                    val connectGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    val scanGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && (!connectGranted || !scanGranted)) {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.BLUETOOTH_CONNECT,
                                Manifest.permission.BLUETOOTH_SCAN
                            )
                        )
                    } else {
                        connectToObd()
                    }
                }) {
                    Text("Conectează la PC (Emulator)")
                }
            }
        }
    }
}