package com.thrust.revreport

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.time.Duration.Companion.milliseconds

class revReportBluetoothManagement(val bluetoothAdapter: BluetoothAdapter?) {

    val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    var currentSocket: BluetoothSocket? = null
    var inputStream: InputStream? = null
    var outputStream: OutputStream? = null

    // 1. Conectarea la adaptor
    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice): Boolean {
        // 1. CRITIC: Orice scanare Bluetooth activă va face ca socket.connect() să eșueze garantat.
        bluetoothAdapter?.cancelDiscovery()

        return try {
            Log.d("RevReport", "Încerc conectarea standard SPP...")
            // UUID-ul standard global pentru Serial Port Profile (SPP)
            val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

            currentSocket = device.createInsecureRfcommSocketToServiceRecord(sppUuid)
            currentSocket?.connect()
            Log.d("RevReport", "Conectare standard reușită!")
            true
        } catch (e: Exception) {
            Log.e("RevReport", "Eșec standard. Încerc forțarea pe canalul 1 (Reflection)...", e)
            try {
                // 2. Metoda de avarie: ocolim SDP-ul și ne legăm direct la canalul RFCOMM 1
                val fallbackMethod = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                currentSocket = fallbackMethod.invoke(device, 1) as? BluetoothSocket
                currentSocket?.connect()
                Log.d("RevReport", "Conectare prin canal de rezervă reușită!")
                true
            } catch (fallbackException: Exception) {
                Log.e("RevReport", "Toate metodele au eșuat: ${fallbackException.message}")
                false
            }
        }
    }

    // 2. Inițializarea adaptorului cu comenzi AT
    suspend fun initializeAdapter() = withContext(Dispatchers.IO) {
        val commands = listOf("AT Z", "AT E0", "AT L0", "AT S0", "AT H0", "AT SP 0")

        for (cmd in commands) {
            try {
                val payload = "$cmd\r".toByteArray()
                outputStream?.write(payload)
                outputStream?.flush()

                if (cmd == "AT Z") {
                    delay(1000.milliseconds)
                } else {
                    delay(200.milliseconds)
                }

                val initResponse = readResponse()
                Log.d("RevReport", "Răspuns la $cmd: $initResponse")

            } catch (e: Exception) {
                Log.e("RevReport", "Eroare la trimiterea comenzii $cmd: ${e.message}")
                break
            }
        }
    }

    // 3. Citirea fluxului de date până la caracterul '>'
    suspend fun readResponse(): String = withContext(Dispatchers.IO) {
        val response = StringBuilder()
        var byteCitit: Int
        var caracter: Char

        try {
            while (true) {
                // Citim un singur byte (literă) din fluxul de date
                byteCitit = inputStream?.read() ?: -1

                // -1 înseamnă că portul a fost închis sau s-a deconectat brusc
                if (byteCitit == -1) break

                caracter = byteCitit.toChar()
                response.append(caracter)

                // Semnalul absolut de oprire în protocolul OBD2
                if (caracter == '>') {
                    break
                }

                // Plasă de siguranță: dacă trecem de 500 de litere, oprim forțat citirea (evităm OOM)
                if (response.length > 500) {
                    Log.w("RevReport", "Răspuns prea lung, am oprit citirea forțat.")
                    break
                }
            }
        } catch (e: Exception) {
            Log.e("RevReport", "Eroare de I/O la citirea răspunsului: ${e.message}")
        }

        // Curățăm răspunsul de spații inutile și eliminăm caracterul '>'
        return@withContext response.toString().replace(">", "").trim()
    }

    suspend fun sendCommand(command: String) = withContext(Dispatchers.IO) {
        try {
            // OBD2 cere ca orice comandă să se termine cu Carriage Return (\r)
            val fullCommand = "$command\r"
            outputStream?.write(fullCommand.toByteArray())
            outputStream?.flush()
            Log.d("RevReport", "Comandă trimisă: $command")
        } catch (e: Exception) {
            Log.e("RevReport", "Eroare la trimiterea comenzii $command: ${e.message}")
        }
    }

    // 4. Curățarea datelor brute
    private fun sanitizeResponse(rawResponse: String): String {
        return rawResponse
            .replace("SEARCHING...", "")
            .replace("\\s".toRegex(), "")
            .replace("STOPPED", "ERROR")
            .trim()
    }

    // 5. Închiderea curată a conexiunii
    fun closeConnection() {
        try {
            inputStream?.close()
            outputStream?.close()
            currentSocket?.close()
        } catch (e: IOException) {
            Log.e("RevReport", "Eroare la închiderea socket-ului: ${e.message}")
        } finally {
            inputStream = null
            outputStream = null
            currentSocket = null
        }
    }
}